<!doctype html>
<html >
@include('admin.layouts.headerlink')
<body>
    @yield('content')
    @include('admin.layouts.footerlink')
    @yield('scripts')
</body>
</html>
