<?php $__env->startSection('content'); ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNK2NX9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main__content_wrapper">
    <div class="container" style="margin-top: 50px; margin-bottom:50px;">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-sm-12 col-md-12 col-lg-6">
                <div class="main-address-box text-center">
                    <h3 class="form-h3">Login</h3>
                    <!-- <form id="submitForm" name="submitForm" method="post" enctype="multipart/form-data"> -->
                    <form method="post" id="login-form" action="<?php echo e(url('login')); ?>" name="login-form">
                    <input type="hidden" name="login_type" value="web">
                                <?php echo csrf_field(); ?>
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="checkout__input--list mb-20 form-group">
                                    <input id="email" type="email" class="checkout__input--field border-radius-5  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                </div>

                                <div class="checkout__input--list mb-20 form-group">
                                    <input id="password" type="password" minlength="6" class="checkout__input--field border-radius-5  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Enter Your Password" required  autofocus>
                                </div>
                        <button type="submit" class="primary__btn w-200" name="submit" value="Submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function ()
    {
        // $('.pace-done').css('background','#f3f3f4');
        $('#login-form').validate({ // initialize the plugin
            rules: {
                email: {
                    noSpace: true,
                    required: true,
                    email: true
                },
                password: {
                    required: true,
                    noSpace:true
                },
            },
            errorElement: 'span',
            errorPlacement: function (error, element) {            
                error.addClass('invalid-feedback');               
                element.closest('.form-group').append(error);
                $('.error').css("font-weight", "bold");
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');                
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            messages: {
                email: {
                    required: "<?php echo e(__('messages.web.user.email_required')); ?>",
                    email: "<?php echo e(__('messages.web.user.email_format')); ?>"
                },
                password: {
                    required: "<?php echo e(__('messages.web.user.password_required')); ?>",
                   
                }
            }
        });

        setTimeout(function(){
            $("div.alert").remove();
        }, 5000 ); // 5 secs
   
    });  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/auth/login.blade.php ENDPATH**/ ?>