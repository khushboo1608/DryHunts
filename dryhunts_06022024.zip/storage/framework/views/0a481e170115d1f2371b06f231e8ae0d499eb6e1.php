
<?php $__env->startSection('content'); ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNK2NX9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main__content_wrapper">
    <?php if(isset($cart_data) &&  count($cart_data)>0): ?>
    <!-- cart section start -->
    <section class="cart__section section--padding">
        <div class="container-fluid">
            <div class="cart__section--inner">
            <!-- <form action="#"> -->
                <h2 class="cart__title mb-40">Shopping Cart</h2>
                <div class="row">
                <div class="col-lg-8">
                    <div class="cart__table">
                    <table class="cart__table--inner">
                        <thead class="cart__table--header">
                        <tr class="cart__table--header__items">
                            <th class="cart__table--header__list">Product</th>
                            <th class="cart__table--header__list">Price</th>
                            <th class="cart__table--header__list">Quantity</th>
                            <th class="cart__table--header__list">Total</th>
                        </tr>
                        </thead>
                        <tbody class="cart__table--body">
                        <?php 
                            $totalamount =0;
                            $total_amount = 0;
                            $totaldisamount =0;
                            $total_dis_amount =0;
                        ?>
                        <?php $__currentLoopData = $cart_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php 
                             $i = $key + 1;
                             ?>
                              
                        <tr class="cart__table--body__items">
                            <td class="cart__table--body__list">
                            <div class="cart__product d-flex align-items-center">
                                <button class="cart__remove--btn cart_remove_product" data-id="<?php echo e($val['cart_id']); ?>" aria-label="search button" type="button" >
                                <!-- <input type="hidden" id="cart_id" name="cart_id" value="<?php echo e($val['cart_id']); ?>"> -->
                                <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16px" height="16px">
                                    <path d="M 4.7070312 3.2929688 L 3.2929688 4.7070312 L 10.585938 12 L 3.2929688 19.292969 L 4.7070312 20.707031 L 12 13.414062 L 19.292969 20.707031 L 20.707031 19.292969 L 13.414062 12 L 20.707031 4.7070312 L 19.292969 3.2929688 L 12 10.585938 L 4.7070312 3.2929688 z"></path>
                                </svg>
                                </button>
                                
                                <div class="cart__thumbnail">
                                    <a href="#"><img class="border-radius-5" src="<?php echo e($val['service_single_image']); ?>" alt="cart-product"></a>
                                </div>
                                <div class="cart__content">
                                <h4 class="cart__content--title">
                                    <a href="#"><?php echo e($val['service_name']); ?></a>
                                </h4>
                                <span class="cart__content--variant">SIZE : <?php echo e($val['service_unit']); ?></span>
                                </div>
                            </div>
                            </td>
                            <td class="cart__table--body__list 1111">
                            <span class="cart__price">₹ <?php echo e($val['cart_service_original_price']); ?></span>

                            <span class="cart__price text-decoration-line">₹ <?php echo e($val['cart_service_discount_price']); ?></span>
                            </td>
                            <td class="cart__table--body__list">
                            <div class="quantity__boxs">
                                <button type="button" class="quantity__value quickview__value--quantity decrease" data-id="" data-type="minus" data-field="" aria-label="quantity value" value="Decrease Value" disabled="">
                                -
                                </button>

                                <input type="number" class="quantity__number quickview__value--number" id="quantity_<?php echo e($i); ?>" name="quantity_<?php echo e($i); ?>" value="<?php echo e($val['cart_service_quantity']); ?>" min="1" disabled="">
                                <button type="button" class="quantity__value quickview__value--quantity increase" data-id="" data-type="plus" data-field="" aria-label="quantity value" value="Increase Value" disabled="">
                                +
                                </button>
                            </div>
                            </td>
                            <td class="cart__table--body__list">
                            <span class="cart__price end">₹<?php echo e($val['cart_service_quantity']*$val['cart_service_original_price']); ?></span>

                            </td>
                            <td>
                            </td>
                        </tr>
                            <?php 
                            $totalamount = $val['cart_service_quantity']*$val['cart_service_original_price'];
                            $total_amount += $totalamount;

                            $totaldisamount = $val['cart_service_quantity']*$val['cart_service_discount_price'];
                            $total_dis_amount += $totaldisamount;

                            ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                    <!-- <div class="continue__shopping d-flex justify-content-between">
                        <a class="continue__shopping--link" href="#">Continue shopping</a>                       
                        <button class="continue__shopping--clear remove_users_cart" id="clearcart">Clear Cart</button>
                    </div> -->
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="cart__summary border-radius-10">
                    <div class="cart__summary--total mb-20">
                        <table class="cart__summary--total__table" id="testing">
                        <tbody>
                            <tr class="cart__summary--total__list">
                            <td class="cart__summary--total__title text-left">
                                Total Price
                            </td>
                            <?php
                           $total_price = $val['cart_service_quantity']*$val['cart_service_discount_price'];
                            ?>
                            <span>₹</span>
                            <td class="cart__summary--amount text-right" id="totl_price"> <?php echo e($total_dis_amount); ?></td>
                            </tr>
                            <tr class="cart__summary--total__list">
                            <td class="cart__summary--total__title text-left">
                            Total Discount Price
                            </td>
                            <?php
                           $total_price = $val['cart_service_quantity']*$val['cart_service_original_price'];
                            ?>
                            <span>₹</span>
                            <td class="cart__summary--amount text-right" id="totl_dis_price"><?php echo e($total_amount); ?></td>
                            </tr>
                            
                            <tr class="cart__summary--total__list">
                            <td class="cart__summary--total__title text-left price-total">
                                Final Amount
                            </td>
                            <td class="cart__summary--amount text-right price-total">
                            ₹ <?php echo e($total_amount); ?>

                            </td>
                            </tr>
                        </tbody>
                        </table>
                    </div>
                    <div class="cart__summary--footer">
                        <ul class="d-flex justify-content-between">                       
                        <button class="cart__summary--footer__btn primary__btn checkout" id="btn-confirm">Check Out</button>
                        </ul>
                    </div>
                    </div>
                </div>
                </div>
            <!-- </form> -->
            </div>
        </div>
    </section>
    <!-- cart section end -->
    <?php else: ?>
    <div class="text-center mt-3">
    <div class="text-center">
        <img class="border-radius-5" src="assets/img/empty_cart.png" alt="cart-product">
    </div>
    <!-- <a class="continue__shopping--link mb-3" href="#">Continue shopping</a> -->
    </div>
    <?php endif; ?>
</main>
<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="mi-modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="myModalLabel">Are you sure?</h3>
        <h5>You want to request this quotation!</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="acceptbtn">YES</button>
        <button type="button" class="btn btn-primary" id="modal-btn-no" data-dismiss="modal">NO</button>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script> -->
  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script>
  $("#btn-confirm").on("click", function(){
    $("#mi-modal").modal('show');
  });
    $('#acceptbtn').on('click', function() {

        var totl_price = $("#totl_price").text();
        var totl_dis_price = $("#totl_dis_price").text();

        $.ajax({
            type: "post",
            data: {
                'order_amount': totl_price,
                'order_discount_amount': totl_dis_price
            },
            url: "<?php echo e(url('/addorder')); ?>",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            dataType: "JSON",
            success: function(response) {
                if(response.result == true)
                {
                    $("#mi-modal").modal('hide');
                    location.href = "<?php echo e(url('orderthankyou')); ?>";
                }
                else{
                    alert(response.result.message);
                }
            }
        });
        return false;
    });
  $("#modal-btn-no").on("click", function(){
    // callback(false);
    $("#mi-modal").modal('hide');
  });

  
    $('.cart_remove_product').on('click', function() {

        var cart_id = $(this).data("id");
        // alert(cart_id);

        $.ajax({
            type: "post",
            data: {
                'cart_id': cart_id,
            },
            url: "<?php echo e(url('/deletecart')); ?>",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            dataType: "JSON",
            success: function(response) {
                if(response.result == true)
                {
                    location.reload();
                }
                else{
                    alert(response.result.message);
                }
            }
        });
        return false;
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vbinfggt/www.codeocean.co.in/2023/B2BProject/resources/views/web/cart.blade.php ENDPATH**/ ?>