
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Service</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Service</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">              
              <div class="col-md-5 col-xs-12">
                <h3 class="card-title">Manage Service</h3>
              </div>
              <div class="col-md-12 col-xs-12">
                    <div class="search_list">
                          <a href="<?php echo e(url('admin/service')); ?>"><button type="button"  class="btn btn-primary waves-effect waves-light"><i class="fa fa-arrow-left"></i>&nbsp;&nbsp;Back</button></a>                        
                    </div>
                </div>    
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
              <form class="form-horizontal" action="<?php echo e(route('service.saveservice')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
              <input type="hidden" name="id" id="id" value="<?php echo e($serviceData->service_id); ?>"> 
                             
                  <div class="form-group row">
                    <label for="category_id" class="col-sm-2 col-form-label">Category Name:-</label>
                    <div class="col-md-6">
                      <select class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="category_id" id="category_id">
                      <option selected="true" disabled="disabled">Choose Category </option>
                          <?php if(isset($master_data) && isset($master_data['category'])): ?>
                              <?php $__currentLoopData = $master_data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item['category_id']); ?>" <?php echo e(( $item['category_id'] == $serviceData['category_id']) ? 'selected' : ''); ?>> <?php echo e($item['category_name']); ?> </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                      </select>                
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="service_name" class="col-sm-2 col-form-label">Service Name :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="service_name" name="service_name" placeholder="Service Name" required="true" value="<?php echo e($serviceData->service_name); ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="service_description" class="col-sm-2 col-form-label">Service Description:-</label>
                    <div class="col-sm-6">
                      <textarea type="Text" class="form-control" id="service_description" name="service_description" placeholder="Service Description" required="true"><?php echo e($serviceData->service_description); ?></textarea>
                      <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script> 
                                <script>CKEDITOR.replace( 'service_description' );</script>
                    </div>
                  </div>
                  
                  <div class="form-group row">
                    <label for="imageurl" class="col-sm-2 col-form-label">Select Image :-</label>
                    <div class="col-sm-6">
                      <div class="fileupload_block">
                        <input name="imageurl"  type="file" value="fileupload" id="fileupload"  accept="image/png, image/jpeg, image/jpg">
                        <?php if(isset($serviceData) && isset($serviceData->imageurl)): ?>
                              <?php if($serviceData->imageurl !=''): ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e($serviceData->imageurl); ?>" style="height: 80px;width: 80px;margin-left: 20px;"  /></div>
                            <?php else: ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e(asset('admin_assets/images/add-image.png')); ?>" /></div>
                            <?php endif; ?>
                          <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label for="service_multiple_image" class="col-sm-2 col-form-label">Select Mutiple Image:-</label>
                    <div class="col-sm-6">
                      <div class="fileupload_block">
                        <input name="service_multiple_image[]" multiple  type="file" value="fileupload" id="fileupload"  accept="image/png, image/jpeg, image/jpg">
                        <div class="fileupload_img"><img type="image" src="<?php echo e(asset('admin_assets/images/add-image.png')); ?>" /></div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <?php 
                      $gallery_img_id = [];
                      $url=route("admin.service");
                      ?>
                      <?php if(isset($serviceData) && isset($serviceData->service_multiple_image)): ?>
                        <?php if($serviceData->service_multiple_image !=''): ?>
                        <?php $__currentLoopData = $serviceData->service_multiple_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-md-2">
                            <div class="fileupload_block">
                              <div class="fileupload_img"><img style="height: 100px;width: 100px;" src="<?php echo e($item); ?>" name="service_multiple_image" id="service_multiple_image" />
                            <!-- <a  href=""><b> Delete </b></a> -->
                                  <?php if($item !=''): ?>
                                    <?php 
                                      $img_id = explode('service_image/', $item);                        
                                      $multiple_image =$img_id[1];
                                    ?>
                                    <a href="<?php echo e($url); ?>/delete_img/<?php echo e($serviceData->service_id); ?>/<?php echo e($multiple_image); ?>" style="margin-left: 20px;"><b> Delete </b></a>
                                  <?php endif; ?>
                              </div>                           
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      <?php endif; ?>
                      </div>                    
                  </div>
                  
                  <!-- <div class="form-group row">
                    <label for="service_price" class="col-sm-2 col-form-label">Service Price :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="service_price" name="service_price" placeholder="Service price" required="true" value="<?php echo e($serviceData->service_price); ?>">
                    </div>
                  </div> -->
                  <div class="form-group row">
                    <label for="service_sku" class="col-sm-2 col-form-label">Service SKU :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="service_sku" name="service_sku" placeholder="Service SKU" required="true" value="<?php echo e($serviceData->service_sku); ?>">
                    </div>
                  </div>
                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Is Popular :-</label>
                      <div class="col-md-6">
                        <input type="checkbox" id="is_popular" name="is_popular" <?php echo e($serviceData->is_popular == 1 ? 'checked' : ''); ?> />
                      </div>
                    </div>  
                  
                  <?php if(isset($serviceData) && isset($serviceData->ServiceDetails)): ?>
                  <?php 
                    $add =0;             
                    ?>
                <?php if(count($serviceData->ServiceDetails)>0): ?>
                <?php 
                  // echo 'if'; die;
                  ?>
                  <div class="form-group">
                  
                      <div id="activity_div" >
                        <?php for($x = 0; $x <= count($serviceData->ServiceDetails)-1 ; $x++): ?> 
                        <input type="hidden" name="service_detail_id[]" id="service_detail_id" value="<?php echo e($serviceData->ServiceDetails[$x]->service_detail_id); ?>"> 
                          <div class="row">
                              <!-- <div class="col-md-2 packate_div">
                                  <label>Quantity:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_quantity" name="service_quantity[]" placeholder="Service quantity" required="true"  value ="<?php echo e($serviceData->ServiceDetails[$x]->service_quantity); ?>">
                              </div> -->
                              <div class="col-md-2 packate_div">
                                  <label>Unit:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_unit" name="service_unit[]" placeholder="Service unit" required="true" value ="<?php echo e($serviceData->ServiceDetails[$x]->service_unit); ?>">
                              </div>
                              <div class="col-md-2 packate_div">
                                  <label>Orignal Price:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_original_price" name="service_original_price[]" placeholder="Service orignal price" required="true" value ="<?php echo e($serviceData->ServiceDetails[$x]->service_original_price); ?>">
                              </div>
                              <div class="col-md-2 packate_div">
                                  <label >Discount Price:</label> <i class="text-danger asterik">*</i>
                                  <input type="text" class="form-control"  name="service_discount_price[]" required=""  placeholder="Service discount price" value ="<?php echo e($serviceData->ServiceDetails[$x]->service_discount_price); ?>"/>
                              </div>
                              
                              <?php if($add ==0): ?>
                              <div class="col-md-1 packate_div">
                                  <label>Add</label>
                                  <a id="add_activity" title="Add activity" style="cursor: pointer;"><i class="fa fa-plus-square-o fa-2x"></i></a>
                              </div>
                          </div>
                          <?php else: ?>
                          <div class="col-md-1" style="display: grid;"><label>Remove</label><a class="remove_activity text-danger" title="Remove activity" style="cursor: pointer;" href="<?php echo e($url); ?>/delete_variation/<?php echo e($serviceData->ServiceDetails[$x]->service_detail_id); ?>"><i class="fa fa-times fa-2x"></i></a></div>
                          <?php endif; ?>
                          <?php 
                          $add++;
                          ?>
                          <?php endfor; ?> 
                      </div>  
                      <div id="activites"></div>                                  
                  </div> 
                  <?php endif; ?>  
                  <?php else: ?>
                  <?php 
                  // echo 'else'; die;
                  ?>
                  <div class="form-group">
                    <!-- <label class="col-md-2 control-label">Other Activities :-</label> -->
                      <div id="activity_div" >
                          <div class="row">
                              <!-- <div class="col-md-2 packate_div">
                              <label>Quantity:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_quantity" name="service_quantity[]" placeholder="Service quantity" required="true" >
                              </div> -->
                              <div class="col-md-2 packate_div">
                                  <label>Unit:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_unit" name="service_unit[]" placeholder="Service unit" required="true" >
                              </div>
                              <div class="col-md-2 packate_div">
                                  <label>Orignal Price:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_original_price" name="service_original_price[]" placeholder="Service orignal price" required="true" >
                              </div>
                              <div class="col-md-2 packate_div">
                                  <label >Discount Price:</label> <i class="text-danger asterik"></i>
                                  <input type="text" class="form-control"  name="service_discount_price[]" required=""  placeholder="Service discount price"/>
                              </div>
                              <div class="col-md-1 packate_div">
                                  <label>Add</label>
                                  <a id="add_activity" title="Add activity" style="cursor: pointer;"><i class="fa fa-plus-square-o fa-2x"></i></a>
                              </div>
                          </div>
                      </div>
                      
                      <div id="activites"></div>
                  </div>
                    
                  <?php endif; ?>

                  <div class="form-group row">
                      <div class="col-sm-6 col-md-offset-3 text-center">
                        <button type="submit" name="submit" class="btn btn-primary">Save</button>
                        <a class="btn btn-danger" href="<?php echo e(url('admin/service')); ?>">Cancel</a>
                      </div>
                  </div>
                </div>

              </form>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

$(document).ready(function(e) {
  $(document).on('click', '.remove_activity', function() {
      $(this).closest('.row').remove();    
  });

  $('#add_activity').on('click', function() {
      html = '<div class="row"><div class="col-md-2 packate_div"><label>Unit:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_unit" name="service_unit[]" placeholder="Service unit" required="true"></div><div class="col-md-2 packate_div"><label>Orignal Price:</label> <i class="text-danger asterik"></i><input type="Text" class="form-control" id="service_orignal_price" name="service_orignal_price[]" placeholder="Service orignal price" required="true"></div><div class="col-md-2 packate_div"><label >Discount Price:</label> <i class="text-danger asterik"></i><input type="text" class="form-control"  name="service_discount_price[]" required=""  placeholder="Service discount price"/></div><div class="col-md-1" style="display: grid;"><label>Remove</label><a class="remove_activity text-danger" title="Remove activity" style="cursor: pointer;"><i class="fa fa-times fa-2x"></i></a></div></div>';
      $('#activites').append(html);
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vbinfggt/www.codeocean.co.in/2023/B2BProject/resources/views/admin/service/edit.blade.php ENDPATH**/ ?>