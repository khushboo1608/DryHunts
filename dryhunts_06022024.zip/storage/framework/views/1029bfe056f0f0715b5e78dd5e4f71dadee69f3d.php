
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('layouts.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('style'); ?>
<?php if(Auth::check()): ?>
<?php endif; ?>
<body class="">
    <div id="app">
      
        <?php echo $__env->yieldContent('content'); ?>
     
    </div>
    <?php echo $__env->make('layouts.footerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/layouts/app.blade.php ENDPATH**/ ?>