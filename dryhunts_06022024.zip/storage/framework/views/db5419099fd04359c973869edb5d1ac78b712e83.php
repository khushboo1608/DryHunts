
<?php $__env->startSection('content'); ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNK2NX9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main__content_wrapper">
    <section class="thank-you__page--area section--padding">
        <div class="container">
        <?php if(session('message')): ?>
        <div class="alert alert-success" id="success_message" role="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
            <img src="./assets/img/thank-you.jpg" class="thank-you">
            <h2 class="success-title text-center">Thank you! Your request have been successfully placed. We would love to serve you.</h2>
            <p class="sub-title-success text-center">Explore us and get amazing offers.</p>
            <div class="d-flex align-items-center justify-content-center gap-10">
             <div class="product__variant--list mb-30">
                <a href="<?php echo e(url('/webhome')); ?>"><button class="variant__buy--now__btn primary__btn" id="gocheckout" type="submit">Explore
                     us</button> </a>
             </div>
             <div class="product__variant--list mb-30">
                  <a href="<?php echo e(url('myorder')); ?>"><button class="variant__buy--now__btn primary__btn pink-color" id="" type="submit">My
                  Request</button> </a>
             </div>
         </div>
        </div>
    </section>
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vbinfggt/www.codeocean.co.in/2023/DryHunts/resources/views/web/orderthankyou.blade.php ENDPATH**/ ?>