<!doctype html>
<html >
<?php echo $__env->make('admin.layouts.headerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('admin.layouts.footerlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home1/vbinfggt/www.codeocean.co.in/2023/B2BProject/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>