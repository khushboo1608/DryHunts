
<?php $__env->startSection('content'); ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNK2NX9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main__content_wrapper">      
        <!-- my account section start -->
        <section class="my__account--section section--padding">
            <div class="container">
                <div class="my__account--section__inner border-radius-10">
                    <div class="account__wrapper">
                        <div class="account__content">
                            <h3 class="account__content--title mb-20">Request History</h3>
                            <div class="account__table--area">
                                <table class="account__table">
                                    <thead class="account__table--header">
                                        <tr class="account__table--header__child">
                                            <th class="account__table--header__child--items">Request Id</th>
                                             <th class="account__table--header__child--items">Date</th>
                                            <th class="account__table--header__child--items">Amount</th>	 	 	
                                           
                                            <th class="account__table--header__child--items">Request Status</th>
                                            <th class="account__table--header__child--items"></th>
                                        </tr>
                                    </thead>
                                   
                                    <tbody class="account__table--body mobile__none">
                                       <?php $__currentLoopData = $order_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="account__table--body__child">
                                            <td class="account__table--body__child--items"><?php echo e($item['order_id']); ?></td>
                                            <td class="account__table--body__child--items"><?php echo e(date('j F, Y, g:i a',strtotime($item['created_at']))); ?></td>

                                            <td class="account__table--body__child--items">₹ <?php echo e($item['order_discount_amount']); ?></td>

                                            <?php 
                                             $order_type = '';
                                             if($item['order_type']== 1){
                                                 $order_type ='pending';
                                             }
                                             else if($item['order_type'] == 2){
                                                 $order_type ='accepted';
                                             }
                                             else if($item['order_type'] == 3){
                                                 $order_type ='work in progress';
                                             }
                                             else if($item['order_type'] == 4){
                                                 $order_type ='completed';
                                             }
                                             else{
                                                 $order_type ='cancelled';
                                             }
                                            ?>

                                            <td class="account__table--body__child--items"><?php echo e($order_type); ?></td>
                                          
                                            <td class="account__table--body__child--items">
                                            <a href="<?php echo e(url('orderdetails/'.$item['order_id'])); ?>" class="primary__btn">View</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>                              
                                </table>
                            </div>
                        </div>
                    </div>   
                </div>
            </div>
        </section>
        <!-- my account section end -->
    </main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\DryHunts\resources\views/web/myorder.blade.php ENDPATH**/ ?>