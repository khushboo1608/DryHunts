
<?php $__env->startSection('content'); ?>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNK2NX9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="shop__section section--padding">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-9 col-lg-8 shop__sidebar--widget-data">
            <div class="shop__product--wrapper">
              <div class="tab_content">
                <div id="product_grid" class="tab_pane active show">
                  <div class="product__section--inner product__grid--inner">
                 
                    <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-3 row-cols-md-3 row-cols-2 mb--n30">
                    <?php if(isset($master_data) && isset($master_data['service'])): ?>
                      <?php $__currentLoopData = $master_data['service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col mb-30">
                      
                        <div class="product__items">
                          <div class="product__items--thumbnail product-lists">
                          <?php
                                $data = app('App\Http\Controllers\Controller');
                                $img1= $data->GetImage($file_name = $item['service_single_image'],$path=config('global.file_path.service_image'));
                                ?>
                            <a class="product__items--link" href="<?php echo e(url('servicedetails/'.$item['service_id'])); ?>">
                              <img class="product__items--img product__primary--img" src="<?php echo e($img1); ?>" alt="product-img">
                            </a>
                            <div class="product__badge">
                              <span class="product__badge--items sale">New</span>
                            </div>
                          </div>
                          <div class="product__items--content responsive-product text-center">
                            
                            <h3 class="product__items--content__title h4">
                              <a href="#"><?php echo e($item['service_name']); ?></a>
                            </h3>
                            <div class="product__items--price">
                              <span class="current__price">₹ <?php echo e($item['ServiceDetails'][0]['service_discount_price']); ?></span>
                              <span class="old__price">₹ <?php echo e($item['ServiceDetails'][0]['service_original_price']); ?></span>
                            </div>
                          </div>
                        </div>
                       
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/web/servicelist.blade.php ENDPATH**/ ?>