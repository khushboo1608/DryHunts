
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Testimonial</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Testimonial</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
              
              <div class="col-md-5 col-xs-12">
                <h3 class="card-title">Manage  Testimonial</h3>
              </div>
              <div class="col-md-12 col-xs-12">
                    <div class="search_list">
                          <a href="<?php echo e(url('admin/testimonial')); ?>"><button type="button"  class="btn btn-primary waves-effect waves-light"><i class="fa fa-arrow-left"></i>&nbsp;&nbsp;Back</button></a>                        
                    </div>
                </div>    
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
              <form class="form-horizontal" action="<?php echo e(route('testimonial.savetestimonial')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
              <input type="hidden" name="id" id="id" value="<?php echo e($testimonialData->testimonial_id); ?>">   
                <div class="card-body">
                <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Select Image :-
                      <p class="control-label-help">(Recommended resolution: 796x360 Image)</p>
                      </label>
                      <div class="col-md-6">
                        <div class="fileupload_block">
                            <!-- <input name="testimonial_image"  type="file" value="fileupload" id="testimonial_image" required="true" accept="image/png, image/jpeg, image/jpg"> -->
                            <input name="testimonial_image"  type="file" value="<?php echo e($testimonialData->testimonial_image); ?>" id="testimonial_image" accept="image/png, image/jpeg, image/jpg" >
                                <?php if(isset($testimonialData) && isset($testimonialData->testimonial_image)): ?>
                                <?php if($testimonialData->testimonial_image !=''): ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e($testimonialData->testimonial_image); ?>" style="width: 100px;height: 100px;"/></div>
                            <?php else: ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e(config('global.no_image.add_image')); ?>" /></div>
                            <?php endif; ?>
                          <?php endif; ?>
                          <input id="testimonial_image" type="hidden" name="testimonial_image_edit"  value="<?php echo e($testimonialData->testimonial_image ?  $testimonialData->testimonial_image:''); ?>" required="true">
                        </div>
                      </div>
                    </div>

                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Testimonial Title :-</label>
                      <div class="col-md-6">
                        <input id="testimonial_title" name="testimonial_title" type="text" class="form-control" required="true"  placeholder="Enter Testimonial Title" value="<?php echo e($testimonialData->testimonial_title); ?>">
                      </div>
                    </div>

                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Testimonial Description :-</label>
                      <div class="col-md-6">
                            
                        <textarea name="testimonial_description" id="testimonial_description" class="form-control"><?php echo e(isset($testimonialData->testimonial_description) ? $testimonialData->testimonial_description : ''); ?></textarea>
                        <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script> 
                        <script>CKEDITOR.replace( 'testimonial_description' );</script>
                        </div>
                      </div>

                      <div class="form-group row">
                    <label for="category_id" class="col-sm-2 col-form-label">Category Name:-</label>
                    <div class="col-md-6">
                      <select class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="category_id" id="category_id">
                      <option selected="true" disabled="disabled">Choose Category </option>
                          
                          <?php if(isset($master_data) && isset($master_data['category'])): ?>
                                <?php $__currentLoopData = $master_data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['category_id']); ?>" <?php echo e(( $item['category_id'] == $testimonialData['category_id']) ? 'selected' : ''); ?>> <?php echo e($item['category_name']); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                      </select>                
                    </div>
                  </div>
                  <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Service :-</label>
                      <div class="col-md-6">
                        <select name="service_id" id="service_id" class="form-control select2 filter" required="true">
                        <option value="0">--Select Service--</option>
                    
                            <?php $__currentLoopData = $master_data['service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $testimonialData['service_id']==$list['service_id']): ?>
                                    <option selected value="<?php echo e($list['service_id']); ?>"><?php echo e($list['service_name']); ?></option>
                                <?php else: ?>
                                    <option  value="<?php echo e($list['service_id']); ?>"><?php echo e($list['service_name']); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>  

                <div class="form-group row">
                      <label class="col-sm-2 col-form-label">State :-</label>
                      <div class="col-md-6">
                        <select name="state_id"  id="state_id" class="form-control select2 filter" >
                          <option selected="true" disabled="disabled">Choose State</option>
                          
                                <?php if(isset($master_data) && isset($master_data['state'])): ?>
                                <?php $__currentLoopData = $master_data['state']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['state_id']); ?>" <?php echo e(( $item['state_id'] == $testimonialData['state_id']) ? 'selected' : ''); ?>> <?php echo e($item['state_name']); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">District :-</label>
                      <div class="col-md-6">
                        <select name="district_id"  id="district_id" class="form-control select2 filter" >
                        <option value="0">--Select District--</option>
                                      <?php $__currentLoopData = $master_data['district']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if( $testimonialData['district_id']==$list['district_id']): ?>
                                              <option selected value="<?php echo e($list['district_id']); ?>"><?php echo e($list['district_name']); ?></option>
                                          <?php else: ?>
                                              <option  value="<?php echo e($list['district_id']); ?>"><?php echo e($list['district_name']); ?></option>
                                          <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Taluka :-</label>
                      <div class="col-md-6">
                        <select name="taluka_id"  id="taluka_id" class="form-control select2 filter" >
                        <option value="0">--Select Taluka--</option>
                                      <?php $__currentLoopData = $master_data['taluka']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if( $testimonialData['taluka_id']==$list['taluka_id']): ?>
                                              <option selected value="<?php echo e($list['taluka_id']); ?>"><?php echo e($list['taluka_name']); ?></option>
                                          <?php else: ?>
                                              <option  value="<?php echo e($list['taluka_id']); ?>"><?php echo e($list['taluka_name']); ?></option>
                                          <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                      </div>
                    </div>         
                    <div class="form-group row">
                      <label class="col-sm-2 col-form-label">Pincode :-</label>
                      <div class="col-md-6">
                        <select name="pincode_id"  id="pincode_id" class="form-control select2 filter" >
                        <option value="0">--Select Pincode--</option>
                                      <?php $__currentLoopData = $master_data['pincode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if( $testimonialData['pincode_id']==$list['pincode_id']): ?>
                                              <option selected value="<?php echo e($list['pincode_id']); ?>"><?php echo e($list['pincode']); ?></option>
                                          <?php else: ?>
                                              <option  value="<?php echo e($list['pincode_id']); ?>"><?php echo e($list['pincode']); ?></option>
                                          <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 
                      </div>
                    </div>                

                  <div class="form-group row">
                      <div class="col-sm-6 col-md-offset-3 text-center">
                        <button type="submit" name="submit" class="btn btn-primary">Save</button>
                        <a class="btn btn-danger" href="<?php echo e(url('admin/testimonial')); ?>">Cancel</a>
                      </div>
                  </div>
                </div>

              </form>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

    // Listen for changes in the first dropdown
      // $('#district_id').html("<option value='' selected disabled>--Select District--</option>");
      $('#state_id').on('change', function() {
          var selectedValue = $(this).val();

          // Make an Ajax request
          $.ajax({
              // url: '/admin/advertisementbanner/get-dropdown-options',
              url : '<?php echo e(url("admin/testimonial/get-dropdown-options")); ?>',
              type: 'GET',
              data: { selectedValue: selectedValue },
              success: function(data) {
                  // Clear existing options in the second dropdown
                  $('#district_id').empty();
                  $('#district_id').html("<option value='' selected disabled >--Select District--</option>");
                  // Populate the second dropdown with the retrieved options
                  $.each(data, function(key, value) {
                      $('#district_id').append($('<option>', {
                          value: key,
                          text: value
                      }));
                  });
              }
          });
      });

      
      // $('#taluka_id').html("<option value='' selected disabled>--Select Taluka--</option>");
      $('#district_id').on('change', function() {
          var selectedValue1 = $(this).val();

          // Make an Ajax request
          $.ajax({
              // url: '/admin/advertisementbanner/get-dropdown-options',
              url : '<?php echo e(url("admin/testimonial/get-dropdown-taluka-options")); ?>',
              type: 'GET',
              data: { selectedValue1: selectedValue1 },
              success: function(data) {
                  // Clear existing options in the second dropdown
                  $('#taluka_id').empty();
                  $('#taluka_id').html("<option value='' selected disabled >--Select Taluka--</option>");
                  // Populate the second dropdown with the retrieved options
                  $.each(data, function(key, value) {
                      $('#taluka_id').append($('<option>', {
                          value: key,
                          text: value
                      }));
                  });
              }
          });
      });

      
      // $('#pincode_id').html("<option value='' selected disabled>--Select Pincode--</option>");
      $('#taluka_id').on('change', function() {
          var selectedValue2 = $(this).val();

          // Make an Ajax request
          $.ajax({
              // url: '/admin/advertisementbanner/get-dropdown-options',
              url : '<?php echo e(url("admin/testimonial/get-dropdown-pincode-options")); ?>',
              type: 'GET',
              data: { selectedValue2: selectedValue2 },
              success: function(data) {
                  // Clear existing options in the second dropdown
                  $('#pincode_id').empty();
                  $('#pincode_id').html("<option value='' selected disabled >--Select Pincode --</option>");
                  // Populate the second dropdown with the retrieved options
                  $.each(data, function(key, value) {
                      $('#pincode_id').append($('<option>', {
                          value: key,
                          text: value
                      }));
                  });
              }
          });
      });
      // $('#service_id').html("<option value='' selected disabled>--Select Service--</option>");
      $('#category_id').on('change', function() {
          var selectedValue3 = $(this).val();

          // Make an Ajax request
          $.ajax({
              // url: '/admin/advertisementbanner/get-dropdown-options',
              url : '<?php echo e(url("admin/testimonial/get-dropdown-service-options")); ?>',
              type: 'GET',
              data: { selectedValue3: selectedValue3 },
              success: function(data) {
                  // Clear existing options in the second dropdown
                  $('#service_id').empty();
                  $('#service_id').html("<option value='' selected disabled >--Select Service --</option>");
                  // Populate the second dropdown with the retrieved options
                  $.each(data, function(key, value) {
                      $('#service_id').append($('<option>', {
                          value: key,
                          text: value
                      }));
                  });
              }
          });
      });
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/admin/testimonial/edit.blade.php ENDPATH**/ ?>