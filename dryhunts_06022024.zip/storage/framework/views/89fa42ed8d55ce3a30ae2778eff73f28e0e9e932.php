
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Order</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Order</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">              
              <div class="col-md-5 col-xs-12">
                <h3 class="card-title">Edit Order</h3>
              </div>
              <div class="col-md-12 col-xs-12">
                    <div class="search_list">
                          <a href="<?php echo e(url('admin/order')); ?>"><button type="button"  class="btn btn-primary waves-effect waves-light"><i class="fa fa-arrow-left"></i>&nbsp;&nbsp;Back</button></a>                        
                    </div>
                </div>    
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
              <form class="form-horizontal" action="<?php echo e(route('order.saveorder')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
              <?php endif; ?>
              <?php if(session('error')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session('error')); ?>

                  </div>
              <?php endif; ?>
              <input type="hidden" name="id" id="id" value="<?php echo e($orderData->order_id); ?>">  
              <input type="hidden" name="user_id" id="user_id" value="<?php echo e($orderData->user_id); ?>">  
                <div class="card-body">
                <div class="form-group row">
                <label class="col-md-2 control-label">User Details:-</label>
                <div class="col-md-3">
                  <input type="text" value="<?php echo e($orderData->User->name); ?>" class="form-control" readonly>
                </div>
                <div class="col-md-3">
                  <input type="text" value="<?php echo e($orderData->User->phone); ?>" class="form-control" readonly>
                </div>
              </div>
              <div class="form-group">
                  <label class="col-md-2 control-label">Service details :-</label>
                  <div class="col-md-10">
                    <table id="t01" style="width:100%" border=1>
                      <tr>
                        <th>Service Name</th>
                        <th>SKU Code</th>
                        <th>Image</th>
                        <th>Variation</th>
                        <th>Price</th>
                      </tr>       
                      <tbody>   
                      <?php $__currentLoopData = $orderData->OrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php 
                      $service_single_image =url(config('global.file_path.service_image')).'/'.$details->ServiceData->service_single_image;
                      // echo $path;die;
                      ?>
                     
                      <input type="hidden" name="order_detail_id []" id="order_detail_id " value="<?php echo e($details->order_detail_id); ?>"> 
                      <tr>
                        
                            <td>
                              <!-- <div class="cart__content">  -->
                              <h4 class="cart__content--title"> <?php echo e($details->ServiceData->service_name); ?> </h4>
                            </td>
                            <td>
                                <span class="cart__content--variant"><?php echo e($details->ServiceData->service_sku); ?> </span><br>
                                      
                              <!-- </div> -->
                            </td>
                              <td>
                                <div class="cart__thumbnail">
                                  <?php if($service_single_image != "") { ?>
                                  <span class="category_img"><img style="height: 50px;width: 50px;" src="<?php echo e($service_single_image); ?>"/></span><?php } ?>
                                </div><br>
                              </td>
                              <td>
                                <span class="cart__content--variant"><?php echo e($details->order_quantity); ?> <?php echo e($details->order_unit); ?> </span><br>
                                      
                              <!-- </div> -->
                            </td>
                                    
                        <td><?php echo e($details->order_discount_price); ?></td>
                      </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                      </tbody>
                    </table>
                  </div>
                </div> 
                  <div class="form-group row">
                    <label for="order_discount_amount" class="col-sm-2 col-form-label">Order Total Amount :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="order_discount_amount" name="order_discount_amount" placeholder="Order Cancel Reason"  value="<?php echo e($orderData->order_discount_amount); ?>">
                    </div>
                  </div>
                  <?php
                                  $timezone = 'Asia/Kolkata';
                                  $currentTime = $details->created_at->timezone($timezone);
                              ?>
                <div class="form-group row">
                <label class="col-md-2 control-label">Created Date :-</label>
                <?php if(isset($details) && isset($currentTime)): ?> 
                            
                <div class="col-md-3">
                  <input type="text" value="<?php echo e($currentTime->format('d/m/Y')); ?>" class="form-control" readonly>
                </div>
                <div class="col-md-3">
                  <input type="text" value="<?php echo e($currentTime->format('H:i:s a')); ?>" class="form-control" readonly>
                </div>
                <?php endif; ?>
              </div>
                  <div class="form-group row">
                    <label for="quotation_remark" class="col-sm-2 col-form-label">Remark :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="quotation_remark" name="quotation_remark" placeholder="Remark"  value="<?php echo e($orderData->quotation_remark); ?>">
                    </div>
                  </div>
                  
                  <!-- <div class="form-group row">
                    <label for="quotation_pdf" class="col-sm-2 col-form-label">Select Quotation PDF:-</label>
                    <div class="col-sm-6">
                      <div class="fileupload_block">
                        <input name="quotation_pdf"  type="file" value="fileupload" id="fileupload"  accept="application/pdf">
                          <?php if(isset($orderData) && isset($orderData->quotation_pdf)): ?>
                              <?php if($orderData->quotation_pdf !=''): ?>
                            <div class="fileupload_img" style="margin-left: 20px;"><?php echo e($orderData->quotation_pdf); ?></div>
                            <?php else: ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e(asset('admin_assets/images/add-image.png')); ?>" /></div>
                            <?php endif; ?>
                          <?php endif; ?>
                      </div>
                    </div>
                  </div> -->
                  <div class="form-group row">
                    <label class="col-md-2 control-label">Order Status :-</label>
                    <div class="col-md-3">
                      <select name="order_type" id="order_type" style="width:280px; height:25px;" class="select2" >
                        <?php if(isset($orderData) && isset($orderData->order_type)): ?> 
                         <option value="1" <?php echo e(1 == $orderData->order_type ? 'selected' : ''); ?>>Pending</option>
                         <option value="2" <?php echo e(2 == $orderData->order_type ? 'selected' : ''); ?>>Accepted</option>
                         <option value="3" <?php echo e(3 == $orderData->order_type ? 'selected' : ''); ?>>InProgress</option>
                         <option value="4" <?php echo e(4 == $orderData->order_type ? 'selected' : ''); ?>>Completed</option>
                         <option value="5" <?php echo e(5 == $orderData->order_type ? 'selected' : ''); ?>>Cancelled</option>
                      </select>
                        <?php endif; ?>
                    </div>
                  </div>
                  <!-- <div class="form-group row">
                    <label for="cancel_reason" class="col-sm-2 col-form-label">Order Cancel Reason :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="cancel_reason" name="cancel_reason" placeholder="Order Cancel Reason"  value="<?php echo e($orderData->cancel_reason); ?>">
                    </div>
                  </div> -->
                  <div class="form-group row">
                      <div class="col-sm-6 col-md-offset-3 text-center">
                        <button type="submit" name="submit" class="btn btn-primary">Save</button>
                        <a class="btn btn-danger" href="<?php echo e(url('admin/order')); ?>">Cancel</a>
                      </div>
                  </div>
                </div>
              </form>
                    <!-- </div> -->
                </div>
                <div class="form-group">
                  <label class="col-md-2 control-label">Order Log :-</label>
                  <div class="col-md-10">
                    <table id="t01" style="width:100%" border=1>
                      <tr>
                        <th>Id</th>
                        <th>User Name</th>
                        <th>description</th>
                        <th>Date</th>
                      </tr>       
                      <tbody>   
                      <?php if(isset($master_data) && !empty($master_data)): ?> 
                      <?php $__currentLoopData = $master_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <?php 
                        // echo "<pre>";
                        // print_r($details->UserData->name);die;
                        ?>
                        
                            <td>
                              <h4 class="cart__content--title"><?php echo e($loop->iteration); ?> </h4>
                              
                            </td>
                            <td>
                                <span class="cart__content--variant"><?php echo e($details->UserData->name); ?></span><br>
                            </td>
                              <td><?php echo e($details->description); ?>

                              </td>
                              <td>
                              <?php
                                  $timezone = 'Asia/Kolkata';
                                  $currentTime = $details->created_at->timezone($timezone);
                              ?>
                              <?php echo e($currentTime); ?>

                            </td>
                      </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        <?php endif; ?>                     
                      </tbody>
                    </table>
                  </div>
                </div> 
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>