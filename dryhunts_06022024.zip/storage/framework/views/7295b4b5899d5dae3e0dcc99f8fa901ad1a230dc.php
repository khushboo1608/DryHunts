
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Banner</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Banner</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
              
              <div class="col-md-5 col-xs-12">
                <h3 class="card-title">Edit Banner</h3>
              </div>
              <div class="col-md-12 col-xs-12">
                    <div class="search_list">
                          <a href="<?php echo e(url('admin/banner')); ?>"><button type="button"  class="btn btn-primary waves-effect waves-light"><i class="fa fa-arrow-left"></i>&nbsp;&nbsp;Back</button></a>                        
                    </div>
                </div>    
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
              <form class="form-horizontal" action="<?php echo e(route('banner.savebanner')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
              <input type="hidden" name="id" id="id" value="<?php echo e($bannerData->banner_id); ?>">   
                <div class="card-body">
                  <div class="form-group row">
                    <label for="banner_name" class="col-sm-2 col-form-label">Banner Name :-</label>
                    <div class="col-sm-6">
                      <input type="Text" class="form-control" id="banner_name" name="banner_name" placeholder="Banner Name" required="true" value="<?php echo e($bannerData->banner_name); ?>">
                    </div>
                  </div>
                  
                  <div class="form-group row">
                    <label for="imageurl" class="col-sm-2 col-form-label">Select Image :-</label>
                    <div class="col-sm-6">
                      <div class="fileupload_block">
                        <input name="imageurl"  type="file" value="fileupload" id="fileupload"  accept="image/png, image/jpeg, image/jpg">
                        <!-- <div class="fileupload_img"><img type="image" src="<?php echo e(asset('admin_assets/images/add-image.png')); ?>"  /></div> -->
                        <?php if(isset($bannerData) && isset($bannerData->imageurl)): ?>
                              <?php if($bannerData->imageurl !=''): ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e($bannerData->imageurl); ?>" style="height: 80px;width: 80px;margin-left: 20px;"  /></div>
                            <?php else: ?>
                            <div class="fileupload_img"><img type="image" src="<?php echo e(asset('admin_assets/images/add-image.png')); ?>" /></div>
                            <?php endif; ?>
                          <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  

                  <div class="form-group row">
                      <div class="col-sm-6 col-md-offset-3 text-center">
                        <button type="submit" name="submit" class="btn btn-primary">Save</button>
                        <a class="btn btn-danger" href="<?php echo e(url('admin/banner')); ?>">Cancel</a>
                      </div>
                  </div>
                </div>

              </form>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
                    <!-- </div> -->
                </div>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
         
         <!-- <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\B2BProject\resources\views/admin/banner/edit.blade.php ENDPATH**/ ?>